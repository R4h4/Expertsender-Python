class Error(Exception):
    """Base class for other exceptions."""
    pass


class ExpertsenderError(Error):
    """Generic Return Error."""
    pass
